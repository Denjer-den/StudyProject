create
    definer = root@localhost procedure usersCount(OUT cnt int)
begin
    select count(*) into cnt from users;
end;

