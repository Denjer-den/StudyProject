create
    definer = root@localhost procedure getUsers(IN usersId int)
begin
    select* from users where id = usersId;
end;

